"""Rotation-policy compliance checking."""
